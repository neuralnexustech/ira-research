# ✅ IRA Research MCP — TODO List
**Architecture: CLI Agent → MCP Server → Chrome Extension → Browser**
**License: MIT Only | All code original | Copyright 2026 IRA Research**

---

## Architecture Reminder

```
[CLI Agent]  →stdio→  [MCP Server]  →TCP→  [Native Host]  →NativeMsg→  [Chrome Extension]  →CDP→  [Chrome]
  Layer 1               Layer 2              Layer 2.5             Layer 3                         Browser
```

> Build order: **bottom-up** → Layer 3 first, then 2.5, then 2, then 1

---

## 📦 Phase 1 — Foundation
*Milestone: CLI Agent can open a tab and take a screenshot end-to-end*

### Step 0 — Project Scaffold
- [ ] Create `ira-research/` at `C:\Users\bidre\Downloads\work\AI AGENT\ira-research\`
- [ ] `LICENSE` (MIT, Copyright 2026 IRA Research)
- [ ] `package.json` — name: `ira-research-mcp`, version: `0.1.0`, license: `MIT`
- [ ] `tsconfig.json` — target: ES2022, module: NodeNext, strict: true
- [ ] `.gitignore` — node_modules, dist, *.js.map
- [ ] `npm install` — deps: `@modelcontextprotocol/sdk`, `zod`, `typescript`, `esbuild`

### Step 1 — Shared Types (used by all layers)
- [ ] `shared/types.ts` — `ToolRequest`, `ToolResponse`, `TabInfo`, `Point`, `Rect`, `FaceResult`
- [ ] `shared/tools.ts` — All 60 tool name constants as `const enum ToolName`
- [ ] `shared/protocol.ts` — Wire protocol: `ping`, `pong`, `client_hello`, `tool_request`, `tool_response`, `error`

---

### LAYER 3 — Chrome Extension (build first)

#### Manifest
- [ ] `extension/manifest.json` — Manifest V3
- [ ] Permissions: `debugger`, `tabs`, `tabGroups`, `activeTab`, `storage`, `alarms`
- [ ] Permissions: `nativeMessaging`, `offscreen`, `sidePanel`, `scripting`, `management`
- [ ] Optional permissions: `tabCapture`, `downloads`
- [ ] Background: `"service_worker": "background/index.js"`
- [ ] Content scripts, devtools page, side panel, options page declared

#### Background Core (Service Worker)
- [ ] `extension/background/index.ts` — Entry point: register all listeners, keepalive alarm every 20s
- [ ] `extension/background/state.ts` — `globalThis.__ira*` maps (survive SW restarts): tabs, sessions, screenshots
- [ ] `extension/background/cdp-engine.ts` — `chrome.debugger` wrapper class
  - [ ] `attachDebugger(tabId)` — attach + enable Page, Runtime, Network, Input domains
  - [ ] `detachDebugger(tabId)` — detach + cleanup
  - [ ] `sendCommand(tabId, method, params)` — auto-reattach on "debugger is not attached"
  - [ ] `sendCommand` timeout (race against configurable ms)
  - [ ] `screenshot(tabId)` — hide overlay → get viewport → resize → CDP captureScreenshot → restore
  - [ ] `click(tabId, x, y, button, count)` — mouseMoved → mousePressed → mouseReleased
  - [ ] `type(tabId, text)` — char-by-char `Input.insertText` + key events
  - [ ] `scroll(tabId, x, y, dx, dy)` — CDP mouseWheel with content-script fallback
  - [ ] Global CDP event listener on `globalThis` for console + network + beforeunload events
- [ ] `extension/background/tab-manager.ts` — Tab group tracking
  - [ ] `createGroup(mainTabId)` — Orange Chrome tab group titled "IRA"
  - [ ] `addTabToGroup(mainTabId, tabId)` — secondary tabs
  - [ ] `findGroupByTab(tabId)` — which group?
  - [ ] `getMcpGroup()` — Yellow group titled "IRA (MCP)"
  - [ ] `hideIndicatorForToolUse(tabId)` → send `HIDE_FOR_TOOL_USE` to content script
  - [ ] `restoreIndicatorAfterToolUse(tabId)` → send `SHOW_AFTER_TOOL_USE`
  - [ ] `TabQueue` class — serial promise chain per tab (prevents race conditions)
- [ ] `extension/background/native-messaging.ts` — Connection to native host
  - [ ] `connectToHost()` — `chrome.runtime.connectNative("com.ira.research")`
  - [ ] Ping/pong probe on connect: `{type:"ping"}` → expect `{type:"pong"}`
  - [ ] Auto-reconnect on port disconnect
  - [ ] Route incoming `tool_request` → `tool-dispatcher.ts`
  - [ ] Send `tool_response` back to native host
- [ ] `extension/background/tool-dispatcher.ts` — Route `tool_request.tool` → handler function

#### First 4 Tools
- [ ] `extension/background/tools/navigation.ts` — `tabs_list`, `tabs_create`, `navigate`
  - [ ] `navigate`: `chrome.tabs.update({url})` + wait for `Page.loadEventFired` via CDP
- [ ] `extension/background/tools/inspection.ts` — `screenshot` (JPEG, adaptive quality, 1568 token budget)

#### Content Script (basic)
- [ ] `extension/content/index.ts` — Message listener: `HIDE_FOR_TOOL_USE`, `SHOW_AFTER_TOOL_USE`
- [ ] `extension/content/overlay.ts` — Glow border animation (IRA purple `rgba(147, 51, 234, 0.5)`)
- [ ] "Stop IRA" button (slide-up, bottom-center) → sends `{type:"STOP_AGENT"}` to background

#### Offscreen Document (keepalive)
- [ ] `extension/offscreen/offscreen.html` — Minimal HTML
- [ ] `extension/offscreen/keepalive.ts` — Ping SW every 20s: `chrome.runtime.sendMessage({type:"SW_KEEPALIVE"})`

---

### LAYER 2.5 — Native Host (stdio ↔ TCP bridge)
- [ ] `host/native-host.ts`
  - [ ] Read stdin: 4-byte little-endian length prefix + JSON message body
  - [ ] Write stdout: 4-byte length prefix + JSON response
  - [ ] Connect to TCP port 18765 (MCP server)
  - [ ] **Primary mode**: if port free → own it, accept extension connections
  - [ ] **Client mode**: if port taken → join existing session (500ms `client_hello` window)
  - [ ] Request ID prefixing: `c{clientId}_{reqId}` for multi-session routing
  - [ ] Replay pending requests if MCP server reconnects within 5s
- [ ] `host/com.ira.research.json` — Native messaging host manifest
  ```json
  { "name": "com.ira.research", "type": "stdio",
    "path": "C:\\...\\ira-research.bat", "allowed_origins": ["chrome-extension://IRA_EXTENSION_ID/"] }
  ```
- [ ] `host/ira-research.bat` — Windows wrapper: `@node "%~dp0native-host.js" %*`
- [ ] `host/install.ps1` — Register `com.ira.research` in Windows registry + compile TS

---

### LAYER 2 — MCP Server
- [ ] `server/mcp-server.ts`
  - [ ] `@modelcontextprotocol/sdk` stdio transport
  - [ ] Primary/Client TCP mode on port 18765
  - [ ] On tool call: validate with Zod → forward to native host → return response
- [ ] `server/session-manager.ts` — Track sessions, route `tool_response` by prefixed ID
- [ ] `server/tool-registry.ts` — Register 4 Phase 1 tools with Zod schemas + rich descriptions
- [ ] `server/transport/stdio.ts` — Stdio MCP transport wrapper
- [ ] `server/transport/tcp.ts` — TCP server/client connection manager

---

### Build System
- [ ] `scripts/build.ts` — esbuild bundles:
  - [ ] `server/` → `dist/server.js` (Node.js CJS)
  - [ ] `host/` → `dist/host/native-host.js` (Node.js CJS)
  - [ ] `extension/background/` → `dist/extension/background.js`
  - [ ] `extension/content/` → `dist/extension/content.js`
  - [ ] `extension/offscreen/` → `dist/extension/offscreen.js`
- [ ] `package.json` scripts: `build`, `dev` (watch), `install-host`

**✅ Phase 1 Done When:** Claude Code MCP config → `node dist/host/native-host.js` → Chrome opens tab → screenshot returned to Claude

---

## 🛠️ Phase 2 — Core Tools (All Layers)
*Milestone: Full browser automation + inspection working*

### LAYER 3 — Content Script (full)
- [ ] `extension/content/ref-manager.ts`
  - [ ] `window.__iraElementMap` WeakRef store
  - [ ] `assignRef(el)` → `"ref_N"` stable ID
  - [ ] `resolveRef(refId)` → element or null (with GC cleanup)
  - [ ] Error: `"Element ref_N not found. Use read_page to get current refs."`
- [ ] `extension/content/accessibility.ts`
  - [ ] `window.__generateIraAccessibilityTree(filter, depth, maxChars, refId)`
  - [ ] Role detection: ARIA role > tag-to-role map (button, link, textbox, combobox, etc.)
  - [ ] Accessible name: aria-label > placeholder > title > alt > label[for] > text content
  - [ ] Viewport filter (skip off-screen unless filter="all")
  - [ ] Output format: `role "name" [ref_N] href="..." type="..." placeholder="..."`
  - [ ] `<select>` children inline as `option "label" (selected) value="x"`
- [ ] `extension/content/element-finder.ts`
  - [ ] ARIA + text match for NL queries
  - [ ] Return up to 20 refs ordered by relevance

### LAYER 3 — Remaining Tools

#### Interaction (12 tools)
- [ ] `click` — coordinate or ref, button type, click count
- [ ] `right_click` — context menu automation
- [ ] `double_click` — with post-action DOM settle wait
- [ ] `triple_click` — select-all pattern
- [ ] `type_text` — char-by-char with random 30-80ms delays
- [ ] `press_key` — full combo: `Ctrl+A`, `Enter`, `Escape`, `F5`, numpad
- [ ] `scroll` — CDP mouseWheel with JS content-script fallback for background tabs
- [ ] `drag` — mousedown hold → step interpolation → mouseup
- [ ] `hover` — mouseMoved only, optional tooltip capture after 500ms
- [ ] `select` — set `<select>` value by label or value string
- [ ] `upload_file` — CDP `DOM.setFileInputFiles` via ref
- [ ] `form_fill_smart` — fill multiple fields from `{ fieldName: value }` object

#### Inspection (9 tools)
- [ ] `read_page` — full a11y tree, configurable depth/filter/refId, 50KB limit
- [ ] `find` — NL query → refs (calls `__generateIraAccessibilityTree` then match)
- [ ] `get_page_text` — article/main extraction, 50KB limit
- [ ] `get_page_html` — cleaned HTML snapshot (strip scripts/styles)
- [ ] `get_element_info` — computed styles, bounding box, ARIA for a ref
- [ ] `take_snapshot` — CDP `DOM.getDocument` full snapshot
- [ ] `highlight_element` — draw labelled overlay box on ref'd element
- [ ] `screenshot_full` — scroll-stitch full-page screenshot
- [ ] `wait_for` — wait for: text appears, ref visible, URL match, network idle, JS truthy

#### JS / Console / Network (7 tools)
- [ ] `eval_js` — `Runtime.evaluate` with awaitPromise, sanitize output (block JWT/cookies)
- [ ] `eval_js_file` — load .js file, execute in page context
- [ ] `read_console` — ring buffer, filter by level/pattern/domain
- [ ] `clear_console` — reset ring buffer for tab
- [ ] `inject_script` — `Page.addScriptToEvaluateOnNewDocument` (persists across navigations)
- [ ] `read_network` — ring buffer, filter by URL/type/status
- [ ] `get_response_body` — `Network.getResponseBody` by requestId

### LAYER 3 — Collectors
- [ ] `extension/background/collectors/console-collector.ts`
  - [ ] Subscribe to `Runtime.consoleAPICalled` + `Runtime.exceptionThrown`
  - [ ] Ring buffer: 10,000 entries per tab
  - [ ] Auto-reset on `Page.frameNavigated` to different domain
- [ ] `extension/background/collectors/network-collector.ts`
  - [ ] Subscribe to `Network.requestWillBeSent` + `Network.responseReceived` + `Network.loadingFailed`
  - [ ] Ring buffer: 1,000 entries per tab
  - [ ] Auto-reset on domain change

### LAYER 2 — MCP Server additions
- [ ] `server/tool-registry.ts` — Register all Phase 2 tools (Zod schemas + descriptions)
- [ ] `server/middleware/arg-coerce.ts` — Normalize: `{x,y}` → `[x,y]`, `"3"` → `3` tabId, etc.
- [ ] `server/middleware/rate-limit.ts` — Per-tool rate limiting (configurable per tool)

**✅ Phase 2 Done When:** Full automation cycle working: navigate → read_page → click ref → type → screenshot → eval_js

---

## 👻🎭 Phase 3 — Ghost Mouse + Test Face + Power Tools
*Milestone: Human-like mouse, face detection, network power, storage tools*

### Ghost Mouse (LAYER 3)
- [ ] `extension/background/ghost-mouse.ts`
  - [ ] `generateBezierPath(start, end, numPoints=50)` — cubic Bezier with random control points
  - [ ] `fittsDelay(distance, targetSize)` → ms — `a + b * log2(D/W + 1)`
  - [ ] `ghostMove(tabId, from, to, opts)` — dispatch ~20 `mouseMoved` CDP events along curve
  - [ ] Per-step random delay: `stepDelay * (0.8 + rand * 0.4)`
  - [ ] Per-step jitter: `±opts.jitter` px on x,y (default 2px)
  - [ ] Overshoot + correction (configurable probability, default 30%)
  - [ ] Pre-click hesitation: 80–200ms random pause before mousedown
  - [ ] Post-click micro-movement: tiny jitter after release
  - [ ] Patch `navigator.webdriver = false` via `Runtime.evaluate` on CDP attach
- [ ] `ghost_click` tool — Bezier move → click (replaces basic `click` for stealth mode)
- [ ] `ghost_move` tool — Move without clicking
- [ ] `ghost_drag` tool — Bezier move with mousedown held → mouseup at destination
- [ ] `set_mouse_personality` tool — `{ moveSpeed, jitter, overshootChance }` per session

### Test Face — MediaPipe (LAYER 3 + Offscreen)
- [ ] Add `@mediapipe/tasks-vision` to package.json
- [ ] Bundle locally: `blaze_face_short.tflite` (models dir)
- [ ] Bundle locally: MediaPipe WASM (`vision_wasm_internal.js` + `.wasm`)
- [ ] `extension/manifest.json` — Add offscreen permission + declare offscreen document
- [ ] `extension/offscreen/offscreen.html` — expand with MediaPipe script
- [ ] `extension/offscreen/face-detector.ts`
  - [ ] `initDetector()` — `FaceDetector.createFromOptions` with local WASM + model paths
  - [ ] `detectFaces(imageData)` → `FaceResult[]`
- [ ] `extension/offscreen/stream-capture.ts` — `captureFrame(streamId)` via getUserMedia
- [ ] `extension/background/tools/face.ts`
  - [ ] `face_detect` tool — source: screenshot (from screenshotStore)
  - [ ] `face_detect` tool — source: webcam (via `chrome.tabCapture`)
  - [ ] `face_detect_video` tool — fake video injection via Chrome flags
  - [ ] `face_count` tool — integer count of detected faces
  - [ ] `face_landmarks` tool — 6 keypoints per face
  - [ ] `face_verify_ui` tool — check page for face detection canvas/UI elements
- [ ] `extension/options/options.ts` — `fakeMedia` config: useFakeDevice, fakeVideoFile

### Performance Tools (LAYER 3)
- [ ] `extension/background/collectors/perf-collector.ts` — Web Vitals via injected PerformanceObserver
- [ ] `measure_vitals` tool — LCP, CLS, FCP, TTFB
- [ ] `start_trace` tool — `Tracing.start` via CDP
- [ ] `stop_trace` tool — `Tracing.end` + collect + summarize top slow functions
- [ ] `measure_fps` tool — FPS counter injection during interaction sequence
- [ ] `lighthouse_audit` tool — Run Lighthouse, return score + opportunities
- [ ] `get_crux_data` tool — Chrome UX Report API → real-user field data

### Storage Tools (LAYER 3)
- [ ] `get_storage` tool — localStorage, sessionStorage, IndexedDB via `Runtime.evaluate`
- [ ] `set_storage` tool — Modify storage values
- [ ] `get_cookies` tool — `Network.getCookies` for current domain
- [ ] `set_cookie` tool — `Network.setCookie`
- [ ] `clear_storage` tool — `Storage.clearDataForOrigin` (selective or full)

### Network Power Tools (LAYER 3)
- [ ] `intercept_request` tool — `Fetch.enable` + fulfill/continue/fail patterns
- [ ] `mock_response` tool — stub any API response for testing
- [ ] `set_throttling` tool — `Network.emulateNetworkConditions` (slow-3G, offline, etc.)
- [ ] `export_har` tool — build HAR 1.2 file from network collector buffer
- [ ] `list_websockets` tool — track WS frames via `Network.webSocketFrameReceived`

### Extension Management Tools (LAYER 3)
- [ ] `list_extensions` tool — `chrome.management.getAll()`
- [ ] `install_extension` tool — load unpacked from path
- [ ] `toggle_extension` tool — `chrome.management.setEnabled(id, enabled)`
- [ ] `reload_extension` tool — `chrome.runtime.reload()` for target extension

### Recording Tools (LAYER 3 + Offscreen)
- [ ] GIF: add `gifenc` to package.json
- [ ] `extension/offscreen/gif-generator.ts` — frame capture + gifenc encode + action overlays
- [ ] `gif_start` tool — start frame capture at configurable rate
- [ ] `gif_stop` tool — stop + return frame count
- [ ] `gif_export` tool — encode GIF, return base64 or download
- [ ] `video_record` tool — WebM recording via `chrome.tabCapture`

### Session / Meta Tools (LAYER 2 + 3)
- [ ] `update_plan` tool — store approved domains in `chrome.storage`
- [ ] `resize_window` tool — `chrome.windows.update({width, height})`
- [ ] `emulate_device` tool — CDP `Emulation.setDeviceMetricsOverride` (mobile/tablet presets)
- [ ] `navigate_back` / `navigate_forward` / `navigate_reload` tools
- [ ] `tabs_close` tool — with before-unload `Page.handleJavaScriptDialog` handling
- [ ] `switch_browser` tool — broadcast to all connected browser profiles

### LAYER 2 — MCP Server additions
- [ ] `server/tool-registry.ts` — Register all Phase 3 tools with Zod schemas

**✅ Phase 3 Done When:** `ghost_click` undetected on anti-bot sites + `face_detect` returning bounding boxes from screenshots

---

## ✨ Phase 4 — DevTools Panel + Polish
*Milestone: Production-ready release*

### DevTools Panel (LAYER 3)
- [ ] `extension/devtools-panel/panel.html`
- [ ] `extension/devtools-panel/panel.ts` — `chrome.runtime.connect` to background
- [ ] Live stream: all tool calls + responses (scrolling log with timing)
- [ ] Per-tool timing: ms duration per call
- [ ] Network waterfall: from network collector, color-coded by type
- [ ] Console log stream: color-coded by level (error=red, warn=yellow, log=gray)
- [ ] Session replay: step through GIF frames with action labels
- [ ] Ghost Mouse visualizer: draw Bezier curve overlay on screenshot
- [ ] Face detection preview: bounding box display with confidence score

### Side Panel (LAYER 3)
- [ ] `extension/sidepanel/sidepanel.html` + `sidepanel.ts`
- [ ] Status: connected/disconnected, active tab ID, current tool running
- [ ] Quick actions: screenshot button, read_page button, navigate bar
- [ ] Mouse mode selector: Precise / Normal / Ghost (stealth)
- [ ] Session info: which CLI agent is connected, session ID

### Options Page (LAYER 3)
- [ ] `extension/options/options.html` + `options.ts`
- [ ] TCP port config (default: 18765)
- [ ] Ghost Mouse defaults: speed multiplier, jitter px, overshoot probability
- [ ] Face detection: model path, confidence threshold, fake webcam path
- [ ] Ring buffer sizes: console (10k), network (1k), screenshots (50)
- [ ] DevTools panel auto-open toggle

### Windows Setup (LAYER 2.5)
- [ ] `host/install.ps1` — full automated setup:
  - [ ] `npm install` + `npm run build`
  - [ ] Register `HKEY_CURRENT_USER\Software\Google\Chrome\NativeMessagingHosts\com.ira.research`
  - [ ] Verify extension ID + update `com.ira.research.json`
  - [ ] Print "✅ IRA Research MCP installed successfully"
- [ ] `README.md` — MIT badge, architecture diagram, setup steps, MCP config snippet

### Final Checks
- [ ] All `package.json` deps are MIT-compatible (verify each)
- [ ] Zero lines copied from `chrome-devtools-mcp` (Apache-2.0)
- [ ] Zero lines copied from Anthropic's extension source
- [ ] MIT license header on every `.ts` source file
- [ ] Test Phase 1: screenshot working via Claude Code
- [ ] Test Phase 2: click + type + read_page full cycle
- [ ] Test Phase 3: ghost_click passes Cloudflare challenge / face_detect returns results
- [ ] Test Phase 4: DevTools panel shows live tool call stream
- [ ] End-to-end test: Claude Code → `screenshot` → `read_page` → `ghost_click` → `screenshot`

---

## 📊 Progress Tracker

| Phase | Layer Focus | Status | Tools | Files |
|-------|-------------|--------|-------|-------|
| Phase 1 — Foundation | Layer 3 core + 2.5 + 2 skeleton | 🔴 Not Started | 0/4 | 0/28 |
| Phase 2 — Core Tools | All layers, 28 tools | 🔴 Not Started | 0/28 | 0/18 |
| Phase 3 — Ghost + Face + Power | Layer 3 advanced | 🔴 Not Started | 0/28 | 0/20 |
| Phase 4 — Polish | All layers | 🔴 Not Started | 0/0 | 0/12 |
| **TOTAL** | | 🔴 **Not Started** | **0/60** | **0/78** |

---

## 🔑 Key Build Rule

> Always build **bottom-up**: Chrome Extension (Layer 3) → Native Host (Layer 2.5) → MCP Server (Layer 2) → Test with CLI Agent (Layer 1)
>
> Never build the MCP Server first — it has nothing to talk to until the Extension + Native Host exist.

---

> Update status: 🔴 Not Started → 🟡 In Progress → 🟢 Done
